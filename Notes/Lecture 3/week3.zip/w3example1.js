//String Object
////////////0123
var str1 = "Welcome to Toronto";
var str2 = 'Muath';
var str3 = `Hello ${str2}`;

var str4 = new String("See you");
console.log(str3);
console.log(str3.length);
console.log(str4.length);
console.log(str2.charAt(2));
console.log(str2.charCodeAt(2));
var str5 = "Hello "+"Sam";
var str6 = "Hello ".concat("Tom").concat("Sam");
console.log(str6);
str7 = "Hello ".concat(str2, " Alzghool");
console.log(str7);

str1 = "Welcome to Toronto";
console.log(str1.indexOf('to'));
console.log(str1.lastIndexOf('to'));
console.log(str1.indexOf('Hello'));

var words = str1.split(' ');
console.log(words);

words = str1.split(/\s+/);
console.log(words);

str1 = "Welcome to Toronto";
console.log(str1.substr(3,6));
console.log(str1.substring(3,6));
console.log(str1.substring(3));
console.log(str1.toUpperCase());
console.log("    Hello     ".trim());
console.log("    Hello     ".trim().toUpperCase().charAt(1));



String.prototype.greeting=function(){
    return "Hello "+this;
};

console.log("Muath".greeting());
console.log("Sam".greeting());


var str9 = "Muath";
String.prototype.reverse = function () {
    var rev = '';
    for (var i = this.length - 1; i >= 0; i--)
       rev += this[i]; // the string
    return rev;
 };

 console.log(str9.reverse());